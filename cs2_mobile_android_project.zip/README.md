# CS2 移动横屏版 — Android 安装包工程

本压缩包为完整的 Android 横屏全屏工程（已通过 `sensorLandscape` 强制锁定横屏并开启沉浸式全屏与硬件加速），内置 `app/src/main/assets/www/index.html` 游戏本体。

## 方式一：GitHub Actions 云端自动生成 APK（无需安装 Android Studio）
1. 在 GitHub 新建一个仓库，将本压缩包解压后的全部文件上传到仓库根目录。
2. 打开仓库顶部的 **Actions** 页面，运行 **Build Android APK** 工作流。
3. 等待约 1~2 分钟构建完成，在页面底部的 **Artifacts** 中下载 `CS2-Mobile-Landscape-APK` 即可获得可直接安装到安卓手机的 `app-debug.apk`。

## 方式二：使用 Android Studio 本地一键出包
1. 打开 Android Studio，选择 **Open** 并选中解压后的文件夹。
2. 等待 Gradle 自动同步完成。
3. 点击顶部菜单 **Build -> Build Bundle(s) / APK(s) -> Build APK(s)**，生成的安装包位于 `app/build/outputs/apk/debug/app-debug.apk`。
